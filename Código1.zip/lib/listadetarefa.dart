import 'package:flutter/material.dart';
import 'package:flutter_application_1/provider/tasks_provider.dart';
import 'package:flutter_application_1/add_task.dart';
import 'package:provider/provider.dart';

class ListaDeTarefas extends StatefulWidget {
  ListaDeTarefas();

  @override
  _EstadoListaDeTarefas createState() => _EstadoListaDeTarefas();
}

class _EstadoListaDeTarefas extends State<ListaDeTarefas> {
  final TextEditingController _controlador = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text('Lista de Tarefas')),
      ),
      body: Consumer<ProvedorTarefas>(
        builder: (context, provedor, child) {
          return ListView.builder(
            itemCount: provedor.tarefas.length,
            itemBuilder: (context, index) {
              return Dismissible(
                key: Key(provedor.tarefas[index]),
                background: Container(
                  color: Colors.red,
                  child: const Icon(Icons.delete, color: Colors.white),
                  alignment: Alignment.centerRight,
                ),
                onDismissed: (direcao) {
                  provedor.removerTarefa(index);
                },
                child: ListTile(
                  title: Center(child: Text(provedor.tarefas[index])),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () {
                          _controlador.text = provedor.tarefas[index];
                          showDialog(
                            context: context,
                            builder: (context) {
                              return AlertDialog(
                                title: const Text('Editar Tarefa'),
                                content: TextField(
                                  controller: _controlador,
                                  onSubmitted: (valor) {
                                    provedor.atualizarTarefa(index, _controlador.text);
                                    Navigator.of(context).pop();
                                  },
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text('Cancelar'),
                                  ),
                                  
                                  TextButton(
                                    onPressed: () {
                                      provedor.atualizarTarefa(index, _controlador.text);
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text('Salvar'),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () {
                          provedor.removerTarefa(index);
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => AdicionarTarefa(),
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
