package com.example.fthht

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
